# Simple Fundraising Page
This project uses HTML, CSS, JavaScript, JQuery, Moment.js and Bootstrap.